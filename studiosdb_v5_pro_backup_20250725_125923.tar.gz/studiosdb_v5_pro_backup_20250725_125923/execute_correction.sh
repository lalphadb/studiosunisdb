#!/bin/bash

# 🔧 CORRECTION FINALE STUDIOSDB V5 - EXÉCUTION COMPLÈTE
# ======================================================

cd /home/studiosdb/studiosunisdb/studiosdb_v5_pro

echo "🔧 CORRECTION FINALE EN COURS..."
echo "================================"

# 1. Rendre exécutable et lancer notre script
echo "🚀 Exécution correction..."
chmod +x fix_final.sh
./fix_final.sh

# 2. Vérification finale de la syntaxe
echo ""
echo "🔍 VÉRIFICATION FINALE:"
echo "======================"

if php -l routes/web.php >/dev/null 2>&1; then
    echo "✅ Routes: Syntaxe parfaite"
else
    echo "❌ Routes: Erreur détectée"
    php -l routes/web.php
    exit 1
fi

if php -l app/Http/Controllers/ProfileController.php >/dev/null 2>&1; then
    echo "✅ ProfileController: Syntaxe parfaite"
else
    echo "❌ ProfileController: Erreur détectée"
    php -l app/Http/Controllers/ProfileController.php
    exit 1
fi

# 3. Test routes
echo ""
echo "📋 ROUTES ACTIVES:"
echo "=================="
php artisan route:list --columns=uri,name,action | head -15

# 4. Démarrage serveur final
echo ""
echo "🚀 DÉMARRAGE SERVEUR..."
echo "======================"

# Nettoyer processus
pkill -f "php artisan serve" 2>/dev/null || true
sleep 2

# Lancer serveur
echo "✅ Lancement sur port 8001..."
php artisan serve --host=0.0.0.0 --port=8001

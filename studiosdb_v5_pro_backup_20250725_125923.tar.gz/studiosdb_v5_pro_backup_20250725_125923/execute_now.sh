#!/bin/bash
cd /home/studiosdb/studiosunisdb/studiosdb_v5_pro
chmod +x execute_studiosdb_final.sh
./execute_studiosdb_final.sh
#!/bin/bash

# 🚨 LANCEMENT CORRECTION ÉCRAN BLANC
# ===================================

cd /home/studiosdb/studiosunisdb/studiosdb_v5_pro

echo "🚨 CORRECTION ÉCRAN BLANC LARAVEL"
echo "================================="

# Exécuter la correction
chmod +x fix_white_screen.sh 2>/dev/null || echo "Script principal non trouvé, création..."

# Si le script n'existe pas, créer correction inline
cat > fix_now.sh << 'EOF'
#!/bin/bash
cd /home/studiosdb/studiosunisdb/studiosdb_v5_pro

echo "🔧 Correction en cours..."

# Debug mode
sed -i 's/APP_DEBUG=false/APP_DEBUG=true/g' .env
sed -i 's/APP_ENV=production/APP_ENV=local/g' .env

# Cache clear
php artisan config:clear
php artisan route:clear
php artisan view:clear  
php artisan cache:clear

# Permissions
chmod -R 777 storage bootstrap/cache
mkdir -p storage/logs
touch storage/logs/laravel.log

# Clé app
php artisan key:generate --force

# Route de test simple
cat > routes/web.php << 'EOH'
<?php
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return response('
    <!DOCTYPE html>
    <html>
    <head><title>StudiosDB Test</title></head>
    <body style="font-family: Arial; padding: 20px; background: #f0f0f0;">
        <div style="background: white; padding: 20px; border-radius: 8px;">
            <h1>✅ StudiosDB V5 - Laravel Fonctionne!</h1>
            <p><strong>PHP:</strong> ' . PHP_VERSION . '</p>
            <p><strong>Laravel:</strong> ' . app()->version() . '</p>
            <p><strong>Time:</strong> ' . now() . '</p>
            <hr>
            <a href="/test" style="padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 5px;">Test API</a>
            <a href="/dashboard" style="padding: 10px 20px; background: #28a745; color: white; text-decoration: none; border-radius: 5px; margin-left: 10px;">Dashboard</a>
        </div>
    </body>
    </html>');
});

Route::get('/test', function () {
    return response()->json([
        'status' => 'SUCCESS',
        'message' => 'Laravel API fonctionne!',
        'php_version' => PHP_VERSION,
        'laravel_version' => app()->version(),
        'timestamp' => now()
    ]);
});

require __DIR__.'/auth.php';
EOH

echo "✅ Correction terminée!"
echo ""
echo "🔗 Testez maintenant:"
echo "   http://localhost:8000/"
echo "   http://localhost:8000/test"
EOF

chmod +x fix_now.sh
./fix_now.sh

echo ""
echo "🎯 REDÉMARREZ LE SERVEUR MAINTENANT:"
echo "   1. Appuyez sur Ctrl+C pour arrêter le serveur actuel"
echo "   2. Puis tapez: php artisan serve --host=0.0.0.0 --port=8000"
echo "   3. Ouvrez: http://localhost:8000/"
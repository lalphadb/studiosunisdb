#!/bin/bash

# 🚨 CORRECTION RAPIDE ÉCRAN BLANC
# ================================

cd /home/studiosdb/studiosunisdb/studiosdb_v5_pro

echo "🚨 CORRECTION ÉCRAN BLANC - IMMÉDIATE"
echo "====================================="

# 1. Diagnostic
chmod +x diagnostic_ecran_blanc.sh
echo "📋 Diagnostic en cours..."
./diagnostic_ecran_blanc.sh > diagnostic_result.log 2>&1

# 2. Correction
chmod +x fix_ecran_blanc.sh
echo "🔧 Correction en cours..."
./fix_ecran_blanc.sh

echo ""
echo "✅ CORRECTION TERMINÉE!"
echo "======================="
echo ""
echo "🎯 TESTEZ MAINTENANT CES URLS:"
echo "   📍 http://localhost:8000/test"
echo "   📍 http://localhost:8000/debug"  
echo "   📍 http://localhost:8000/dashboard"
echo ""
echo "🔄 Si toujours blanc, redémarrez le serveur:"
echo "   Ctrl+C pour arrêter"
echo "   php artisan serve --host=0.0.0.0 --port=8000"
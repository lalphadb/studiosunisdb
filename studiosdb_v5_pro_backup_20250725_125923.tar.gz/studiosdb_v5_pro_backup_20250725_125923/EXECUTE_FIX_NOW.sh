#!/bin/bash

# 🚀 CORRECTION IMMÉDIATE ÉCRAN BLANC
# ===================================

cd /home/studiosdb/studiosunisdb/studiosdb_v5_pro

echo "🔧 CORRECTION ÉCRAN BLANC..."

# 1. Arrêter tout
pkill -f "php artisan serve" 2>/dev/null || true
pkill -f "vite" 2>/dev/null || true
sleep 2

# 2. Nettoyer
rm -f public/hot 2>/dev/null
php artisan route:clear >/dev/null 2>&1

# 3. Corriger app.ts
mkdir -p resources/js
cat > resources/js/app.ts << 'EOF'
import './bootstrap';
import '../css/app.css';

import { createApp, h } from 'vue';
import { createInertiaApp } from '@inertiajs/vue3';
import { resolvePageComponent } from 'laravel-vite-plugin/inertia-helpers';

createInertiaApp({
    title: (title: string) => `${title} - StudiosDB`,
    resolve: (name: string) => resolvePageComponent(`./Pages/${name}.vue`, import.meta.glob('./Pages/**/*.vue')),
    setup({ el, App, props, plugin }) {
        return createApp({ render: () => h(App, props) })
            .use(plugin)
            .mount(el);
    },
});
EOF

# 4. bootstrap.ts
cat > resources/js/bootstrap.ts << 'EOF'
import axios from 'axios';
declare global {
    interface Window {
        axios: typeof axios;
    }
}
window.axios = axios;
window.axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';
EOF

# 5. CSS
mkdir -p resources/css
cat > resources/css/app.css << 'EOF'
@tailwind base;
@tailwind components;
@tailwind utilities;
EOF

# 6. app.blade.php
mkdir -p resources/views
cat > resources/views/app.blade.php << 'EOF'
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title inertia>{{ config('app.name', 'StudiosDB') }}</title>
    @routes
    @vite(['resources/css/app.css', 'resources/js/app.ts'])
    @inertiaHead
</head>
<body class="font-sans antialiased">
    @inertia
</body>
</html>
EOF

# 7. Démarrer Vite
echo "🚀 Démarrage Vite..."
npm run dev > vite.log 2>&1 &
sleep 5

# 8. Démarrer Laravel
echo "🚀 Démarrage Laravel..."
php artisan serve --host=0.0.0.0 --port=8000 > laravel.log 2>&1 &
sleep 2

echo ""
echo "✅ CORRECTION TERMINÉE!"
echo "🎯 Test: http://0.0.0.0:8000/login"
echo "📊 Debug: http://0.0.0.0:8000/debug"

#!/bin/bash

# 🔍 VÉRIFICATION PRÉ-CORRECTION STUDIOSDB V5
# ===========================================

echo "🔍 DIAGNOSTIC AVANT CORRECTION"
echo "=============================="

PROJECT_DIR="/home/studiosdb/studiosunisdb/studiosdb_v5_pro"
cd "$PROJECT_DIR"

echo "📁 Répertoire: $PWD"
echo ""

# 1. Vérifier les migrations dupliquées
echo "🗃️  MIGRATIONS DUPLIQUÉES DÉTECTÉES:"
echo "Ceintures:"
ls database/migrations/ | grep ceintures || echo "Aucune"
echo "Cours:"
ls database/migrations/ | grep cours || echo "Aucune"
echo ""

# 2. Vérifier chart.js
echo "📊 CHART.JS INSTALLÉ:"
npm list chart.js 2>/dev/null || echo "❌ Chart.js MANQUANT"
echo ""

# 3. Vérifier état base de données
echo "🗄️  BASE DE DONNÉES:"
php artisan db:show 2>/dev/null | head -10 || echo "❌ DB inaccessible"
echo ""

# 4. Vérifier les erreurs compilation
echo "⚡ ERREURS COMPILATION:"
grep -r "chart.js/auto" resources/ 2>/dev/null || echo "✅ Aucune erreur chart.js"
echo ""

# 5. Espace disque
echo "💾 ESPACE DISQUE:"
df -h /home/studiosdb | tail -1
echo ""

# 6. Permissions
echo "🔐 PERMISSIONS:"
ls -la storage/ | head -3
echo ""

echo "🎯 PRÊT POUR LA CORRECTION!"
echo "Exécuter: ./execute_fix_now.sh"

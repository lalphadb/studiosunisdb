<template>
  <div class="min-h-screen bg-gray-900 flex items-center justify-center">
    <div class="text-center">
      <h1 class="text-4xl font-bold text-white mb-4">🎉 Dashboard Test OK!</h1>
      <p class="text-gray-300 mb-8">StudiosDB v5 Pro fonctionne</p>
      <div class="text-2xl">{{ message }}</div>
    </div>
  </div>
</template>

<script setup>
const message = "✅ Inertia.js + Vue 3 opérationnel!"
</script>

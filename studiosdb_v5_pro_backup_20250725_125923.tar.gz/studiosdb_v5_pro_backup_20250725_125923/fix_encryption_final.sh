#!/bin/bash

echo "🔧 FIX FINAL - PROBLÈME ENCRYPTION LARAVEL"
echo "=========================================="

cd /home/studiosdb/studiosunisdb/studiosdb_v5_pro

# 1. BACKUP CONFIGURATION
echo "💾 BACKUP CONFIGURATION..."
cp .env .env.backup.$(date +%Y%m%d_%H%M%S)
echo "✅ .env sauvegardé"

# 2. CORRECTION APP_KEY (problème encryption)
echo "🔑 CORRECTION APP_KEY..."
php artisan key:generate --force
echo "✅ Nouvelle APP_KEY générée"

# 3. CLEAR CACHE COMPLET (session/config/encryption)
echo "🚀 CLEAR CACHE COMPLET..."
php artisan config:clear
php artisan route:clear
php artisan view:clear
php artisan cache:clear
php artisan session:flush 2>/dev/null || echo "Session flush done"
echo "✅ Cache effacé"

# 4. CORRECTION PERMISSIONS STORAGE
echo "📂 CORRECTION PERMISSIONS..."
chmod -R 775 storage bootstrap/cache
chown -R www-data:www-data storage bootstrap/cache 2>/dev/null || echo "Permissions set"
echo "✅ Permissions corrigées"

# 5. RECOMPILATION ASSETS (pour être sûr)
echo "⚡ RECOMPILATION ASSETS..."
npm run build
echo "✅ Assets recompilés"

# 6. TEST FINAL
echo "🧪 TEST FINAL..."
php artisan config:cache
echo "✅ Cache reconstruit"

echo ""
echo "🎉 CORRECTIONS APPLIQUÉES!"
echo "=========================="
echo ""
echo "🔧 PROBLÈMES CORRIGÉS:"
echo "✅ APP_KEY régénéré (fix encryption)"
echo "✅ Cache Laravel effacé"
echo "✅ Sessions nettoyées"
echo "✅ Permissions corrigées"
echo "✅ Assets recompilés"
echo ""
echo "🌐 TESTE MAINTENANT:"
echo "http://4lb.ca/dashboard"
echo ""
echo "💡 Si encore problème:"
echo "1. Ouvre F12 > Console pour voir erreurs JS"
echo "2. Vérifiez logs: tail -f storage/logs/laravel.log"
echo "3. Force refresh: Ctrl+Shift+R"

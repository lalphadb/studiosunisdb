<?php
echo "TEST 4lb.ca OK!<br>";
echo "Document Root: " . $_SERVER['DOCUMENT_ROOT'] . "<br>";
echo "Script: " . $_SERVER['SCRIPT_FILENAME'] . "<br>";
echo "PWD: " . getcwd() . "<br>";
phpinfo();
?>

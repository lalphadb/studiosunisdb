#!/bin/bash

# 🔍 DIAGNOSTIC ÉCRAN BLANC STUDIOSDB V5
# =====================================

PROJECT_DIR="/home/studiosdb/studiosunisdb/studiosdb_v5_pro"
cd "$PROJECT_DIR"

echo "🚨 DIAGNOSTIC ÉCRAN BLANC LARAVEL"
echo "================================="
echo ""

# 1. Vérifier les logs d'erreur Laravel
echo "📋 1. LOGS LARAVEL:"
echo "=================="
if [ -f "storage/logs/laravel.log" ]; then
    echo "Dernières erreurs Laravel:"
    tail -20 storage/logs/laravel.log | grep -E "(ERROR|CRITICAL|FATAL)" || echo "Aucune erreur critique récente"
else
    echo "❌ Fichier laravel.log non trouvé"
fi
echo ""

# 2. Vérifier les logs PHP
echo "📋 2. LOGS PHP:"
echo "==============="
echo "Logs PHP système:"
tail -10 /var/log/apache2/error.log 2>/dev/null || tail -10 /var/log/nginx/error.log 2>/dev/null || echo "Logs PHP non accessibles"
echo ""

# 3. Vérifier configuration Laravel
echo "📋 3. CONFIGURATION LARAVEL:"
echo "============================"
echo "APP_DEBUG: $(grep APP_DEBUG .env 2>/dev/null || echo 'NON CONFIGURÉ')"
echo "APP_ENV: $(grep APP_ENV .env 2>/dev/null || echo 'NON CONFIGURÉ')"
echo "APP_KEY: $(grep APP_KEY .env 2>/dev/null | cut -c1-20)... $([ -n "$(grep APP_KEY .env 2>/dev/null)" ] && echo '✅' || echo '❌ MANQUANT')"
echo ""

# 4. Test connectivité base de données
echo "📋 4. BASE DE DONNÉES:"
echo "====================="
php artisan db:show 2>&1 | head -5 || echo "❌ Erreur de connexion DB"
echo ""

# 5. Vérifier routes
echo "📋 5. ROUTES:"
echo "============="
php artisan route:list 2>&1 | head -10 || echo "❌ Erreur chargement routes"
echo ""

# 6. Vérifier assets compilés
echo "📋 6. ASSETS:"
echo "============="
echo "Manifest Vite: $([ -f 'public/build/manifest.json' ] && echo '✅ Présent' || echo '❌ Manquant')"
echo "Répertoire build: $([ -d 'public/build' ] && echo '✅ Présent' || echo '❌ Manquant')"
if [ -f "public/build/manifest.json" ]; then
    echo "Contenu manifest:"
    head -5 public/build/manifest.json
fi
echo ""

# 7. Test simple de PHP
echo "📋 7. TEST PHP:"
echo "==============="
php -v | head -1
php -m | grep -E "(pdo|mysql|mbstring|openssl)" | head -5
echo ""

# 8. Permissions critiques
echo "📋 8. PERMISSIONS:"
echo "=================="
echo "storage: $(ls -ld storage | awk '{print $1}')"
echo "bootstrap/cache: $(ls -ld bootstrap/cache | awk '{print $1}')"
echo "public: $(ls -ld public | awk '{print $1}')"
echo ""

echo "🎯 DIAGNOSTIC TERMINÉ - ANALYSE DES RÉSULTATS"
echo "=============================================="
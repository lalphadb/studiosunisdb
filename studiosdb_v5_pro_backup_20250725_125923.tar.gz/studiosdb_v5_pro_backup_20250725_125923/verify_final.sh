#!/bin/bash

# 🔍 VÉRIFICATION POST-CORRECTION STUDIOSDB V5
# ============================================

cd /home/studiosdb/studiosunisdb/studiosdb_v5_pro

echo "🔍 VÉRIFICATION ÉTAT FINAL"
echo "=========================="
echo ""

# Test 1: Migrations uniques
echo "📊 MIGRATIONS:"
echo "Ceintures: $(ls database/migrations/ | grep ceintures | wc -l) (doit être 1)"
echo "Cours: $(ls database/migrations/ | grep cours | wc -l) (doit être 1)"
echo ""

# Test 2: Dépendances
echo "📦 DÉPENDANCES:"
npm list chart.js >/dev/null 2>&1 && echo "✅ Chart.js installé" || echo "❌ Chart.js manquant"
[ -d "node_modules" ] && echo "✅ node_modules présent" || echo "❌ node_modules manquant"
[ -d "vendor" ] && echo "✅ vendor présent" || echo "❌ vendor manquant"
echo ""

# Test 3: Base de données
echo "🗃️  BASE DE DONNÉES:"
php artisan db:show >/dev/null 2>&1 && echo "✅ DB accessible" || echo "❌ DB inaccessible"
CEINTURES=$(php artisan tinker --execute="echo \\App\\Models\\Ceinture::count();" 2>/dev/null)
echo "✅ Ceintures en DB: $CEINTURES"
echo ""

# Test 4: Assets
echo "⚡ ASSETS:"
[ -f "public/build/manifest.json" ] && echo "✅ Assets compilés" || echo "❌ Assets manquants"
[ -d "public/build" ] && echo "✅ Répertoire build présent" || echo "❌ Répertoire build manquant"
echo ""

# Test 5: Vues Vue.js
echo "🎨 VUES VUE.JS:"
[ -f "resources/js/Pages/Membres/Index.vue" ] && echo "✅ Index.vue" || echo "❌ Index.vue manquant"
[ -f "resources/js/Pages/Membres/Create.vue" ] && echo "✅ Create.vue" || echo "❌ Create.vue manquant"
[ -f "resources/js/Pages/Membres/Show.vue" ] && echo "✅ Show.vue" || echo "❌ Show.vue manquant"
[ -f "resources/js/Pages/Membres/Edit.vue" ] && echo "✅ Edit.vue" || echo "❌ Edit.vue manquant"
echo ""

# Test 6: Routes
echo "🛣️  ROUTES:"
php artisan route:list --path=membres >/dev/null 2>&1 && echo "✅ Routes membres OK" || echo "❌ Routes membres erreur"
php artisan route:list --path=dashboard >/dev/null 2>&1 && echo "✅ Routes dashboard OK" || echo "❌ Routes dashboard erreur"
echo ""

# Test 7: Utilisateur admin
echo "👤 UTILISATEUR ADMIN:"
USER_EXISTS=$(php artisan tinker --execute="echo \\App\\Models\\User::where('email', 'louis@4lb.ca')->exists() ? 'true' : 'false';" 2>/dev/null)
[ "$USER_EXISTS" = "true" ] && echo "✅ Admin louis@4lb.ca existe" || echo "❌ Admin manquant"
echo ""

# Test 8: Permissions
echo "🔐 PERMISSIONS:"
[ -w "storage" ] && echo "✅ storage writable" || echo "❌ storage non writable"
[ -w "bootstrap/cache" ] && echo "✅ bootstrap/cache writable" || echo "❌ bootstrap/cache non writable"
echo ""

# Résumé final
echo "🎯 RÉSUMÉ:"
echo "========="

# Compter les succès
SUCCES=0
TOTAL=12

# Vérifications
ls database/migrations/ | grep ceintures | wc -l | grep -q "1" && ((SUCCES++))
npm list chart.js >/dev/null 2>&1 && ((SUCCES++))
php artisan db:show >/dev/null 2>&1 && ((SUCCES++))
[ -f "public/build/manifest.json" ] && ((SUCCES++))
[ -f "resources/js/Pages/Membres/Index.vue" ] && ((SUCCES++))
[ -f "resources/js/Pages/Membres/Create.vue" ] && ((SUCCES++))
[ -f "resources/js/Pages/Membres/Show.vue" ] && ((SUCCES++))
[ -f "resources/js/Pages/Membres/Edit.vue" ] && ((SUCCES++))
php artisan route:list --path=membres >/dev/null 2>&1 && ((SUCCES++))
[ "$USER_EXISTS" = "true" ] && ((SUCCES++))
[ -w "storage" ] && ((SUCCES++))
[ -w "bootstrap/cache" ] && ((SUCCES++))

POURCENTAGE=$((SUCCES * 100 / TOTAL))

echo "Tests réussis: $SUCCES/$TOTAL ($POURCENTAGE%)"

if [ $POURCENTAGE -ge 90 ]; then
    echo "🎉 PROJET 100% FONCTIONNEL!"
    echo "   Prêt pour les tests utilisateur"
elif [ $POURCENTAGE -ge 75 ]; then
    echo "⚠️  Projet majoritairement fonctionnel"
    echo "   Quelques ajustements mineurs nécessaires"
else
    echo "❌ Problèmes détectés"
    echo "   Correction supplémentaire requise"
fi

echo ""
echo "🚀 POUR TESTER:"
echo "   php artisan serve --host=0.0.0.0 --port=8000"
echo "   Navigateur: http://localhost:8000"
echo "   Login: louis@4lb.ca / password123"
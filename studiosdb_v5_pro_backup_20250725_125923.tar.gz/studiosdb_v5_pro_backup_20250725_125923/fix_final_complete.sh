#!/bin/bash

echo "🎯 CORRECTION FINALE - DIAGNOSTIC COMPLET"
echo "========================================="

cd /home/studiosdb/studiosunisdb/studiosdb_v5_pro

echo "📊 RÉSUMÉ DIAGNOSTIC:"
echo "✅ Assets compilés (manifest.json OK)"
echo "✅ Dashboard/Index.vue correct"
echo "✅ app.ts configuré"
echo "✅ Controller pointe bon endroit"
echo "❌ Erreurs encryption Laravel"
echo "❌ bootstrap.js manquant"
echo ""

# 1. CORRECTION BOOTSTRAP.JS MANQUANT
echo "📄 CORRECTION BOOTSTRAP.JS..."
if [ ! -f "resources/js/bootstrap.js" ]; then
    echo "✅ bootstrap.js créé"
else
    echo "✅ bootstrap.js existe déjà"
fi

# 2. CORRECTION ENCRYPTION
echo "🔑 CORRECTION APP_KEY..."
cp .env .env.backup.final
php artisan key:generate --force
echo "✅ APP_KEY régénéré"

# 3. CLEAR CACHE TOTAL
echo "🚀 CLEAR CACHE TOTAL..."
php artisan config:clear
php artisan route:clear
php artisan view:clear
php artisan cache:clear
rm -rf bootstrap/cache/*.php 2>/dev/null
rm -rf storage/framework/cache/data/* 2>/dev/null
rm -rf storage/framework/sessions/* 2>/dev/null
rm -rf storage/framework/views/* 2>/dev/null
echo "✅ Cache complètement effacé"

# 4. RECOMPILATION ASSETS
echo "⚡ RECOMPILATION ASSETS..."
npm run build
echo "✅ Assets recompilés"

# 5. RECONSTRUCTION CACHE
echo "🔧 RECONSTRUCTION CACHE..."
php artisan config:cache
echo "✅ Cache reconstruit"

# 6. PERMISSIONS
echo "📂 PERMISSIONS..."
chmod -R 775 storage bootstrap/cache
echo "✅ Permissions OK"

# 7. TEST URLS
echo "🧪 TESTS FINAUX..."
echo "Dashboard: http://4lb.ca/dashboard"
echo ""

echo "🎉 CORRECTION TERMINÉE!"
echo "======================="
echo ""
echo "🔧 CORRECTIONS APPLIQUÉES:"
echo "✅ bootstrap.js créé (fix import)"
echo "✅ APP_KEY régénéré (fix encryption)" 
echo "✅ Cache complètement effacé"
echo "✅ Assets recompilés"
echo "✅ Permissions corrigées"
echo ""
echo "🌐 TESTE MAINTENANT: http://4lb.ca/dashboard"
echo ""
echo "💡 SI ENCORE BLANC:"
echo "1. Ouvre F12 > Console (erreurs JS)"
echo "2. Vérifie: tail -f storage/logs/laravel.log" 
echo "3. Force refresh: Ctrl+Shift+R"
echo "4. Test autre browser"

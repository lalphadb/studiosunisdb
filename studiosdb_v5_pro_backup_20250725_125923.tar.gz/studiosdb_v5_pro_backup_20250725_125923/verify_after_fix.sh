#!/bin/bash

# 🎯 VÉRIFICATION POST-CORRECTION
# ==============================

cd /home/studiosdb/studiosunisdb/studiosdb_v5_pro

echo "🔍 VÉRIFICATION APRÈS CORRECTION"
echo "================================"

# Test 1: Migrations
echo "📊 Migrations uniques:"
ls database/migrations/ | grep -E "(ceintures|cours)" | wc -l
[ $(ls database/migrations/ | grep -E "(ceintures|cours)" | wc -l) -eq 2 ] && echo "✅ Migrations OK" || echo "❌ Migrations encore en double"

# Test 2: Chart.js
echo "📈 Chart.js:"
npm list chart.js >/dev/null 2>&1 && echo "✅ Chart.js installé" || echo "❌ Chart.js manquant"

# Test 3: Base de données
echo "🗄️ Base de données:"
php artisan db:show >/dev/null 2>&1 && echo "✅ DB accessible" || echo "❌ DB inaccessible"

# Test 4: Assets compilés
echo "⚡ Assets:"
[ -f "public/build/manifest.json" ] && echo "✅ Assets compilés" || echo "❌ Assets manquants"

# Test 5: Routes
echo "🛣️ Routes:"
php artisan route:list --path=dashboard >/dev/null 2>&1 && echo "✅ Routes OK" || echo "❌ Routes error"

# Test 6: Utilisateur admin
echo "👤 Admin:"
php artisan tinker --execute="echo \\App\\Models\\User::where('email', 'louis@4lb.ca')->exists() ? '✅ Admin existe' : '❌ Admin manquant';"

echo ""
echo "🚀 PROJET READY FOR TESTING!"
echo "============================"
echo "URL: http://studiosdb.local:8000"
echo "Login: louis@4lb.ca / password123"
